var username;
var admin;
var alert_timeout;

$(document).ready(function () {

  login(null, null);

  $("#login-page form").submit(function (event) {
    event.preventDefault();
    var $form = $(this),
      username = $form.find("input[name='username']"),
      password = $form.find("input[name='password']");
    if (!username.val().length) {
      showMessage("error", "Username required.");
      username.focus();
    } else if (!password.val().length) {
      showMessage("error", "Password required.");
      password.focus();
    } else {
      login(username.val(), password.val());
    }
  });

  $("#profile-page form").submit(function (event) {
    event.preventDefault();
    var $form = $(this),
      username = $form.find("input[name='username']"),
      password = $form.find("input[name='password']");
      confirmation = $form.find("input[name='confirmation']");
    if (!username.val().length) {
      showMessage("error", "Username required.");
      username.focus();
    } else if (!password.val().length) {
      showMessage("error", "Password required.");
      password.focus();
    } else if (!confirmation.val().length) {
      showMessage("error", "Confirmation required.");
      password.focus();
    } else if (confirmation.val() != password.val()) {
      showMessage("error", "Passwords do not match.");
      password.focus();
    } else {
      $.post("/api/edit-user", {
        username: username.val(),
        password: password.val()
      }, function (response) {
        if (response.success) {
          window.username = username.val();
          showMessage("success", response.message);
        } else {
          showMessage("error", response.message);
        }
      }, "json");
    }
  });

  $("#add-users-page form").submit(function (event) {
    event.preventDefault();
    var $form = $(this),
      username = $form.find("input[name='username']"),
      password = $form.find("input[name='password']"),
      confirmation = $form.find("input[name='confirmation']"),
      admin = $form.find("input[name='admin']");
    if (!username.val().length) {
      showMessage("error", "Username required.");
      username.focus();
    } else if (!password.val().length) {
      showMessage("error", "Password required.");
      password.focus();
    } else if (!confirmation.val().length) {
      showMessage("error", "Confirmation required.");
      password.focus();
    } else if (confirmation.val() != password.val()) {
      showMessage("error", "Passwords do not match.");
      password.focus();
    } else {
      $.post("/api/add-user", {
        username: username.val(),
        password: password.val(),
        admin: admin.val()
      }, function (response) {
        if (response.success) {
          showMessage("success", response.message);
        } else {
          showMessage("error", response.message);
        }
      }, "json");
    }
  });
});

function showMessage(type, message) {
  var alert = $("#" + type);

  clearTimeout(alert_timeout);
  alert.stop().fadeIn(0, function () {
    alert.find(".message").empty().append(message);
    alert_timeout = setTimeout(function () {
      alert.fadeOut();
    }, 3000);
  });
}

function showPage(name) {
  var tabs = $(".nav li");
  var pages = $("#pages > div");

  if (name === "default") {
    var show_tabs = tabs.not("#login-tab");

    tabs.each(function () {
      $(this).hide();
    });
    if (!admin) {
      show_tabs = show_tabs.not("#admin-dropdown");
    }
    show_tabs.not("#login-tab").each(function () {
      $(this).show();
    });
    name = "home";
  } else if (name === "login") {
    tabs.each(function () {
      $(this).hide();
    });
    $("#login-tab").show();
  } else if (name === "profile") {
    $("#profile-page").find("input[name='username']").val(username);
  } else if (name === "remove-users") {
    var tbody = $('#remove-users-page tbody');

    tbody.hide();
    $.get("/api/list-users", function (response) {
      tbody.empty();
      if (response.success) {
        $(response.users).each(function () {
          tbody.append("<tr><td>" + this.username + "</td><td><span class=\"glyphicon glyphicon-" +
                       (this.admin ? "ok" : "remove") + "\" aria-hidden=\"true\"></span></td><td>\
                       <span class=\"glyphicon glyphicon-trash pointer\" aria-hidden=\"true\"\
                       onclick=\"removeUser(this);\"></span></td></tr>");
        });
        tbody.fadeIn();
      } else {
        showMessage("error", response.message);
      }
    }, "json");
  }
  tabs.each(function () {
    $(this).removeClass("active");
  });
  pages.each(function () {
    $(this).hide();
  });
  $("#" + name + "-tab").addClass("active");
  $("#" + name + "-page").show();
  document.title = "HTTPRequest - " + name.charAt(0).toUpperCase() + name.slice(1);
}

function login(username, password) {
  var params = {};

  if (username && password) {
    params["username"] = username;
    params["password"] = password;
  }
  $.post("/api/login", params, function (response) {
    if (response.success) {
      window.username = response.username;
      admin = response.admin;
      showPage("default");
      showMessage("success", response.message);
    } else {
      if (username && password) {
        showMessage("error", response.message);
      } else {
        showPage("login");
      }
    }
  }, "json");
}

function logout() {
  $.get("/api/logout", function (response) {
    showPage("login");
    if (response.success) {
      showMessage("success", response.message);
    } else {
      showMessage("error", response.message);
    }
  }, "json");
}

function toggleStatusLED() {
  $.get("/api/toggle-status-led", function (response) {
    if (response.success) {
      showMessage("success", response.message);
    } else {
      showMessage("error", response.message);
    }
  }, "json");
}

function removeUser(data) {
  var td = $(data).parent();

  $.post("/api/remove-user", {
    username: td.siblings(":first").text()
  }, function (response) {
    if (response.success) {
      var tbody = $('#remove-users-page tbody');

      td.parent().remove();
      showMessage("success", response.message);
    } else {
      showMessage("error", response.message);
    }
  }, "json");
}