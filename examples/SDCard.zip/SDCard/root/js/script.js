var username;
var alert;
var alert_timeout;

$(document).ready(function () {

  // Get state from server on page load
  $.get("/api/login", function (response) {
    if (response.success) {
      $("#menu").show();
      $("#control-panel").show();
      username = response.username;
      showMessage("#success", response.message);
    } else {
      $("#login").show();
    }
  }, "json");

  $("#login form").submit(function (event) {
    event.preventDefault();
    var $form = $(this),
      form_username = $form.find("input[name='username']"),
      form_password = $form.find("input[name='password']");
    if (!form_username.val().length) {
      showMessage("#error", "Username required.");
      form_username.focus();
    } else if (!form_password.val().length) {
      showMessage("#error", "Password required.");
      form_password.focus();
    } else {
      $.post("/api/login", {
        username: form_username.val(),
        password: form_password.val()
      }, function (response) {
        if (response.success) {
          username = form_username.val();
          $("#login").hide();
          $("#menu").show();
          $("#control-panel").show();
          showMessage("#success", response.message);
        } else {
          showMessage("#error", response.message);
        }
      }, "json");
    }
  });

  $("#settings form").submit(function (event) {
    event.preventDefault();
    var $form = $(this),
      form_username = $form.find("input[name='username']"),
      form_password = $form.find("input[name='password']");
      form_confirmation = $form.find("input[name='confirmation']");
    if (!form_username.val().length) {
      showMessage("#error", "Username required.");
      form_username.focus();
    } else if (!form_password.val().length) {
      showMessage("#error", "Password required.");
      form_password.focus();
    } else if (!form_confirmation.val().length) {
      showMessage("#error", "Confirmation required.");
      form_password.focus();
    } else if (form_confirmation.val() != form_password.val()) {
      showMessage("#error", "Passwords do not match.");
      form_password.focus();
    } else {
      $.post("/api/edit", {
        username: form_username.val(),
        password: form_password.val()
      }, function (response) {
        if (response.success) {
          username = form_username.val();
          hideSettings();
          showMessage("#success", response.message);
        } else {
          showMessage("#error", response.message);
        }
      }, "json");
    }
  });
});

function logout() {
  $.get("/api/logout", function (response) {
    $("#menu").hide();
    $("#control-panel").hide();
    $("#login").show();
    if (response.success) {
      showMessage("#success", response.message);
    } else {
      showMessage("#error", response.message);
    }
  }, "json");
}

function showMessage(element, message) {
  if (alert_timeout) {
    clearTimeout(alert_timeout);
  }
  if (alert) {
    alert.hide();
  }
  alert = $(element);
  alert.empty().append(message).show();
  alert_timeout = setTimeout(function () {
    alert.fadeOut();
  }, 3000);
}

function showSettings() {
  $("#control-panel").hide();
  $("#settings").show();
  $("#settings form").find("input[name='username']").val(username);
}

function hideSettings() {
  $("#settings").hide();
  $("#control-panel").show();
}

function toggleStatusLED() {
  $.get("/api/toggle", function (response) {
    if (response.success) {
      showMessage("#success", response.message);
    } else {
      showMessage("#error", response.message);
    }
  }, "json");
}